
package com.webroothackathon.app.problem13;

/*
 * Helper class
 */
public class Response {

    public String name;
}
