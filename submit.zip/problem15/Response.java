
package com.webroothackathon.app.problem15;

/*
 * Helper class
 */
public class Response {

    public long time;
}
