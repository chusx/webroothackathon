
package com.webroothackathon.app.problem13;

/*
 * Helper class
 */
public class Request {

    public Request() {}
}
