package com.webroothackathon.app.problem5;

import java.util.*;

/*
 * Helper class
 */
public class Request {

    public ArrayList<String> ips;
}
