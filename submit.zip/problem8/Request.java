package com.webroothackathon.app.problem8;

public class Request {

    public double[] x_coords;
    public double[] y_coords;
    public double[] radii;
    public double start_x;
    public double start_y;
    public double end_x;
    public double end_y;
}
