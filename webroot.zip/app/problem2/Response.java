package com.webroothackathon.app.problem2;

import com.webroothackathon.app.problem1.UrlCatItem;

import java.util.*;

/*
 * Helper class
 */
public class Response {

    public List<UrlCatItem> urlItems;
}
