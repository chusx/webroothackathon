
package com.webroothackathon.app.problem11;

/*
 * Helper class
 */
public class Response {

    public boolean synchronizedOrder;
}
