package com.webroothackathon.app.problem3;

/*
 * Helper class
 */
public class Request {

    public int[] set;
    public int startInt;
    public int endInt;

    public Request() {}
}
