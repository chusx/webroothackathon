package com.webroothackathon.app.problem1;

import java.util.*;

/*
 * Helper class
 */
public class Request {

    public List<UrlCatItem> urlItems; 

    public Request() {
        urlItems = new ArrayList<UrlCatItem>();
    }
}
