
package com.webroothackathon.app.problem9;

/*
 * Helper class
 */
public class Response {

    public int maximumCounter;
}
