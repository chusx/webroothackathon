package com.webroothackathon.app.problem1;

/*
 * Helper class
 */
public class Response {

    public int category;
    public int reputation;
}
