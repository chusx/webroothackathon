
package com.webroothackathon.app.problem9;

/*
 * Helper class
 */
public class Request {

    public Request() {}
}
