
package com.webroothackathon.app.problem11;

/*
 * Helper class
 */
public class Request {

    public Request() {}
}
