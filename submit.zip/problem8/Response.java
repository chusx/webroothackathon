package com.webroothackathon.app.problem8;

public class Response {
    public int circlesToCross;
}
