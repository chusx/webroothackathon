package com.webroothackathon.app.problem0;

/*
 * Helper class
 */
public class Response {

    public long sum;
}
