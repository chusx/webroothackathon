package com.webroothackathon.app.problem0;

/*
 * Helper class
 */
public class Request {

    public int first;
    public int second;
}
