package com.webroothackathon.app.problem3;

/*
 * Helper class
 */
public class Response {

    public int missingInt;
}
