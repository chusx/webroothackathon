package com.webroothackathon.app.problem10;

/*
 * Helper class
 */
public class Response {
    public String[] attemptedPins;
}
