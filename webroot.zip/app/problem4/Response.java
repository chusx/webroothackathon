package com.webroothackathon.app.problem4;

/*
 * Helper class
 */
public class Response {

    public String snake;
}
