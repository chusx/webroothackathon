
package com.webroothackathon.app.problem15;

/*
 * Helper class
 */
public class Request {

    public Request() {}
}
