package com.webroothackathon.app.problem0;

/*
 * Takes in two ints, adds them together and returns the result
 *
 * @param (a) first integer to be added
 * @param (b) second integer to be added
 * @return a long of param a added to param b
 *
 */
public class Problem0
{
	public static long Add( int a, int b)
	{
		return (long) a + (long) b;
	}
}
