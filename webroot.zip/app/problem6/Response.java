package com.webroothackathon.app.problem6;

import java.util.*;

/*
 * Helper class
 */
public class Response {

    public ArrayList<StringPair> topUrlsPerCat;
}
