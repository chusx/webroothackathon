package com.webroothackathon.app.problem10;

/*
 * Helper class
 */
public class Request {

    public String observedPin;
}
