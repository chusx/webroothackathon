package com.webroothackathon.app.problem12;

import java.util.List;

public class Response {
    public List<String> urls;
}
